# ltframe  -- webkit desktop applaction framework,use HTML,CSS,javascript



LTFrame is a Windows application development framework .it based on the WebKit, you can use HTML,CSS, JavaScript.The web page development technology to develop your applications , you also can use HTML5, CSS3

LTFrame using the standard WIN32, SDK C++ , without MFC

LTFrame runs in the Windows2000 or higher operating system

You can use the VS2005, VS2008, or higher version of the VS for the application development

The use of LTFrame is totally free and you can use it in any application.
