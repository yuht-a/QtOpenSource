#ifndef __BUILDCFG__
#define __BUILDCFG__


#define VI_VERSION %version%
#define VI_VERSION_STR "%version%\0"


#endif
