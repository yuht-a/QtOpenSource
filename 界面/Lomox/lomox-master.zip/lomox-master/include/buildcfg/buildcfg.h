#ifndef __BUILDCFG__
#define __BUILDCFG__


#define VI_VERSION 1,0,0,1006
#define VI_VERSION_STR "1,0,0,1006\0"


#endif
