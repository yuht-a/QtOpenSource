<?php return array (
  0 => '第1个元素!',
  1 => '第2个元素!',
);