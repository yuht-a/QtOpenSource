﻿/*******************************************************************************
* 版权所有(C) 2010-2013 caidongyun. All Rights Reserved.
*
* 文件名称	: lxinternalplugins.h
* 作    者	: 蔡东赟 (mailto:caidongyun19@qq.com)
* 创建日期	: 2013/4/22
* 功能描述	: 
* 备    注	: 
********************************************************************************/
#ifndef __LXINTERNALPLUGINS_H__
#define __LXINTERNALPLUGINS_H__

#include "lxpluginbase.h"

class LxPlugins : public QObject
{
public:
	LxPlugins(QObject* parent):QObject(parent){}
	virtual LxPlugins(){}


private:
	//QMap
};




class 






#endif // end of __LXINTERNALPLUGINS_H__
