﻿/*******************************************************************************
* 版权所有(C) 2011-2012  caidongyun All Rights Reserved.
*
* 文件名称	: lxsqldatabase.h
* 作    者	: 蔡东赟 (mailto:caidongyun19@qq.com)
* 创建日期	: 2012/2/15
* 功能描述	: 
* 备    注	: 
********************************************************************************/
#ifndef __LXSQLDATABASE_H__
#define __LXSQLDATABASE_H__

#endif // end of __LXSQLDATABASE_H__
