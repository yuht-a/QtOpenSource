﻿#ifndef LOMOX_H
#define LOMOX_H

#include "lomox_global.h"

class LOMOX_EXPORT lomox
{
public:
	lomox();
	~lomox();

private:

};

#endif // LOMOX_H
