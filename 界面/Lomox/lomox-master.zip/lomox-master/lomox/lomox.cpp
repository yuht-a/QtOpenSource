﻿#include "lomox.h"

lomox::lomox()
{
}

lomox::~lomox()
{

}
