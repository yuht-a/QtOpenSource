﻿#pragma once

#ifdef  Q_OS_WIN32
#include <windows.h>
#include <qt_windows.h>
#include <winuser.h>
#endif
#include <vector>
#include <string>
using namespace std;

#include <algorithm>




