﻿/*******************************************************************************
* 版权所有(C) 2011-2012 LomoX. All Rights Follow Lomox1 licence.
*
* 文件名称	: lxwindows.cpp
* 作    者	: 蔡东赟 (mailto:caidongyun19@qq.com)
* 创建日期	: 2012/2/6
* 功能描述	: 
* 备    注	: 
********************************************************************************/
#include "lomox_global.h"
#include "lxwindows.h"


LxWindows::LxWindows( LxCoreApplication* lxApp, )
{

}

LxWindows::~LxWindows()
{

}

QObject* LxWindows::item( QVariant varIndex )
{
 
}

QVariant LxWindows::count()
{
	
}
