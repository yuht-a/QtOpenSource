﻿/*******************************************************************************
* 版权所有(C) 2011-2011 LomoX. caidongyun All Rights Reserved.
*
* 文件名称	: definename.h
* 作    者	: 蔡东赟 (mailto:caidongyun19@qq.com)
* 创建日期	: 2011/12/31
* 功能描述	: 
* 备    注	: 
********************************************************************************/
#ifndef __DEFINENAME_H__
#define __DEFINENAME_H__

#define LOMOX_API_COREAPP "LomoX"
#define LOMOX_API_DIALOG "LxDialog"

#endif // end of __DEFINENAME_H__
