C:\\Qt\\Qt5.3.1\\Tools\\mingw482_32\\bin\\mingw32-make.exe clean
C:\\Qt\\Qt5.3.1\\5.3\\mingw482_32\\bin\\qmake.exe QCFramer.pro -r -spec win32-g++
C:\\Qt\\Qt5.3.1\\Tools\\mingw482_32\\bin\\mingw32-make.exe
